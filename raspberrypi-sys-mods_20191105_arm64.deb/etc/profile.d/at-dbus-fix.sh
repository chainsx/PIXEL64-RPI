if ! [ -e /usr/share/dbus-1/services/org.a11y.Bus.service ] ; then
   export NO_AT_BRIDGE=1
fi
